from main import app

# This file is used to run the FastAPI application with gunicorn
# It exports the FastAPI application instance for ASGI servers like gunicorn to use